package com.becomedigital.sdk.identity.becomedigitalsdk.callback;

public class LoginError {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String pMessage) {
        message = pMessage;
    }
}
